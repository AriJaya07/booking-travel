
<!-- jQuery -->
<script src="<?= base_url() ?>adminlte/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url() ?>adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="<?= base_url() ?>adminlte/plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?= base_url() ?>adminlte/plugins/moment/moment.min.js"></script>
<!-- date-range-picker -->
<script src="<?= base_url() ?>adminlte/plugins/daterangepicker/daterangepicker.js"></script>
<!-- BS-Stepper -->
<script src="<?= base_url() ?>adminlte/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?= base_url() ?>adminlte/plugins/dropzone/min/dropzone.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url() ?>adminlte/dist/js/adminlte.min.js"></script>
<!-- Summernote -->
<script src="<?= base_url() ?>adminlte/plugins/summernote/summernote-bs4.min.js"></script>
<!-- DataTables -->
<script src="<?= base_url() ?>adminlte/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url() ?>adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>