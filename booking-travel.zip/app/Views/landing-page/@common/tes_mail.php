<!DOCTYPE html>
<html>
<head>
    <title>Your Email Title</title>
</head>
<body>
    <h1>Hello, {name}!</h1>
    <p>This is a sample HTML email template.</p>
</body>
</html>
